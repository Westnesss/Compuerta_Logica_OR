/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ec.edu.uce.compuertalogicaor;

import java.util.Scanner;

/**
 *
 * @author David
 */
public class LogicGateOr {
    
    public static boolean Or(boolean input1, boolean input2){
        return input1 || input2;
    }
            
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        System.out.println("--Logic Gate OR--");
        boolean input1;
        boolean input2;
        System.out.println("input 1st value--true-false--");
        input1=leer.nextBoolean();
        System.out.println("input 2nd value--true-false--");
        input2=leer.nextBoolean();
        
        boolean output = Or(input1,input2);
        
        System.out.println("input 1: "+input1);
        System.out.println("input 2: "+input2);
        System.out.println("Output (OR): "+output);
        
        
        
    
        
    }
}
